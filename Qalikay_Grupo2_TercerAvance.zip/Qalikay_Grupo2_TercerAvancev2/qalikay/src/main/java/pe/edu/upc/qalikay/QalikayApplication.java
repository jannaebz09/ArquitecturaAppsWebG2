package pe.edu.upc.qalikay;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class QalikayApplication {

	public static void main(String[] args) {
		SpringApplication.run(QalikayApplication.class, args);
	}

}

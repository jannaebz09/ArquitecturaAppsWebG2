package pe.edu.upc.qalikay;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class QalikayApplicationTests {

	@Test
	void contextLoads() {
	}

}

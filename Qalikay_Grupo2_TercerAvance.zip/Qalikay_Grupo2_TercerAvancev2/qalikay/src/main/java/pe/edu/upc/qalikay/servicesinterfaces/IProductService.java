package pe.edu.upc.qalikay.servicesinterfaces;

public interface IProductService {
}

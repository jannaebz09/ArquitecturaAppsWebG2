package pe.edu.upc.qalikay.dtos;

public class ProductDTO {
}

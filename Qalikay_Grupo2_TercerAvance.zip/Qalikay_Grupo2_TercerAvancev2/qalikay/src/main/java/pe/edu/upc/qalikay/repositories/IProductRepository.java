package pe.edu.upc.qalikay.repositories;

public interface IProductRepository {
}

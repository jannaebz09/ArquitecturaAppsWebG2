package pe.edu.upc.qalikay.entities;


import jakarta.persistence.Entity;
import jakarta.persistence.Table;

public class Product {

}
